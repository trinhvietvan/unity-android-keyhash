package van.nzt;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Base64;
import android.util.Log;

import java.security.MessageDigest;

public class UnityAndroidKeyHash {

    public static String GetKeyHash(Activity activity) {
        String keyHashString = "";

        try {
            final PackageInfo info = activity.getPackageManager().getPackageInfo(activity.getPackageName(), PackageManager.GET_SIGNATURES);

            for (android.content.pm.Signature signature : info.signatures) {
                final MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                final String keyHash = new String(Base64.encode(md.digest(), 0));

                if(keyHash != null && keyHash.isEmpty() == false) {
                    keyHashString = keyHash;
                    Log.v("VANTV", "Keyhash: " + keyHashString);
                }
            }
        } catch (Exception e) {
            Log.e("VANTV", "Get KeyHash Error: ", e);
        }

        return keyHashString;
    }
}
